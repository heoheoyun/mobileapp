package com.example.learningapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class StatsActivity extends AppCompatActivity {
    TextView tvTotal, tvFavorite, tvLast;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        tvTotal = findViewById(R.id.tv_total);
        tvFavorite = findViewById(R.id.tv_favorite);
        tvLast = findViewById(R.id.tv_last);
        db = new DBHelper(this);

        loadStats();
    }

    private void loadStats() {
        int total = 0;
        int favorite = 0;
        String lastDate = "없음";

        Cursor allCursor = db.getAllLearnings();
        Cursor favCursor = db.getFavorites();

        if (allCursor != null) {
            total = allCursor.getCount();
            if (allCursor.moveToFirst()) {
                lastDate = allCursor.getString(allCursor.getColumnIndexOrThrow("timestamp"));
            }
        }

        if (favCursor != null) {
            favorite = favCursor.getCount();
        }

        tvTotal.setText(getString(R.string.total_items, total));
        tvFavorite.setText(getString(R.string.favorite_items, favorite));
        tvLast.setText(getString(R.string.last_registered, lastDate));
    }
}
