package com.example.learningapp;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.example.learningapp.model.LearningItem;

import java.util.*;

public class QuizActivity extends AppCompatActivity {

    private static final String TAG = "QuizActivity";

    private TextView tvQuestion, tvResult;
    private Button btnTrue, btnFalse, btnNext;
    private List<LearningItem> quizItems;
    private final Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        tvQuestion = findViewById(R.id.tv_quiz_question);
        tvResult = findViewById(R.id.tv_result);
        btnTrue = findViewById(R.id.btn_answer_true);
        btnFalse = findViewById(R.id.btn_answer_false);
        btnNext = findViewById(R.id.btn_next);

        loadQuizData();

        btnTrue.setOnClickListener(v -> checkAnswer(true));
        btnFalse.setOnClickListener(v -> checkAnswer(false));
        btnNext.setOnClickListener(v -> showNextQuestion());
    }

    private void loadQuizData() {
        quizItems = new ArrayList<>();

        try (DBHelper db = new DBHelper(this);
             Cursor cursor = db.getAllLearnings()) {

            while (cursor.moveToNext()) {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String desc = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                boolean fav = cursor.getInt(cursor.getColumnIndexOrThrow("is_favorite")) == 1;

                // ✅ 수정된 부분: 4개의 인자 전달
                quizItems.add(new LearningItem(id, title, desc, fav));
            }

        } catch (Exception e) {
            Log.e(TAG, "퀴즈 데이터 로드 중 오류 발생", e);
        }

        if (quizItems.isEmpty()) {
            tvQuestion.setText(R.string.no_data);
            btnTrue.setEnabled(false);
            btnFalse.setEnabled(false);
        } else {
            showNextQuestion();
        }
    }

    private void showNextQuestion() {
        tvResult.setText("");
        btnNext.setVisibility(View.GONE);

        int currentIndex = random.nextInt(quizItems.size());
        LearningItem currentQuestion = quizItems.get(currentIndex);

        boolean makeFalse = random.nextBoolean();
        String shownTitle = makeFalse ? getRandomWrongTitle(currentQuestion.getTitle()) : currentQuestion.getTitle();

        String questionText = currentQuestion.getDescription() +
                "\n\n" +
                getString(makeFalse ? R.string.false_answer : R.string.true_answer) +
                ": \"" + shownTitle + "\"";

        tvQuestion.setText(questionText);
        tvQuestion.setTag(!makeFalse);
    }

    private String getRandomWrongTitle(String correctTitle) {
        for (int i = 0; i < 10; i++) {
            int idx = random.nextInt(quizItems.size());
            String title = quizItems.get(idx).getTitle();
            if (!title.equals(correctTitle)) return title;
        }
        return "???";
    }

    private void checkAnswer(boolean userAnswer) {
        boolean correctAnswer = (boolean) tvQuestion.getTag();

        if (userAnswer == correctAnswer) {
            tvResult.setText(R.string.quiz_result_correct);
        } else {
            tvResult.setText(R.string.quiz_result_wrong);
        }

        btnNext.setVisibility(View.VISIBLE);
    }
}
