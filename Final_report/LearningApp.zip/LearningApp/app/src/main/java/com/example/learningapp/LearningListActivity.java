package com.example.learningapp;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.learningapp.model.LearningItem;
import java.util.ArrayList;
import java.util.List;

public class LearningListActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    DBHelper db;
    List<LearningItem> itemList;
    LearningAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learning_list);

        recyclerView = findViewById(R.id.recycler_learning);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        db = new DBHelper(this);
        itemList = new ArrayList<>();

        loadData();
    }

    private void loadData() {
        Cursor cursor = db.getAllLearnings();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
            String desc = cursor.getString(cursor.getColumnIndexOrThrow("description"));
            int isFav = cursor.getInt(cursor.getColumnIndexOrThrow("is_favorite"));
            itemList.add(new LearningItem(id, title, desc, isFav == 1));
        }

        adapter = new LearningAdapter(this, itemList, new LearningAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(LearningItem item) {
                int newFav = item.isFavorite() ? 0 : 1;
                db.updateFavorite(item.getId(), newFav);
                Toast.makeText(LearningListActivity.this, newFav == 1 ? "즐겨찾기 추가됨" : "즐겨찾기 해제됨", Toast.LENGTH_SHORT).show();
                recreate();
            }

            @Override
            public void onItemLongClick(LearningItem item) {
                new AlertDialog.Builder(LearningListActivity.this)
                        .setTitle("삭제 확인")
                        .setMessage("이 항목을 삭제하시겠습니까?")
                        .setPositiveButton("삭제", (dialog, which) -> {
                            db.deleteLearning(item.getId());
                            Toast.makeText(LearningListActivity.this, "삭제됨", Toast.LENGTH_SHORT).show();
                            recreate();
                        })
                        .setNegativeButton("취소", null)
                        .show();
            }
        });

        recyclerView.setAdapter(adapter);
    }
}
