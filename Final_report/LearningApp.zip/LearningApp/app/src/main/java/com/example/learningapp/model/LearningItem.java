package com.example.learningapp.model;

public class LearningItem {
    private final int id;
    private final String title;
    private final String description;
    private final boolean isFavorite;

    public LearningItem(int id, String title, String description, boolean isFavorite) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.isFavorite = isFavorite;
    }

    // ✅ 오류 해결: ID를 외부에서 가져올 수 있게 함
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public boolean isFavorite() {
        return isFavorite;
    }
}
