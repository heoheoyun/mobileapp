package com.example.learningapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.*;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "LearningApp.db";
    private static final int DB_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE learning (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT NOT NULL," +
                "description TEXT NOT NULL," +
                "is_favorite INTEGER DEFAULT 0," +
                "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {
        db.execSQL("DROP TABLE IF EXISTS learning");
        onCreate(db);
    }

    public boolean insertLearning(String title, String desc, int isFavorite) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("title", title);
        cv.put("description", desc);
        cv.put("is_favorite", isFavorite);
        long result = db.insert("learning", null, cv);
        return result != -1;
    }

    public Cursor getAllLearnings() {
        return getReadableDatabase().rawQuery("SELECT * FROM learning ORDER BY timestamp DESC", null);
    }

    public Cursor getFavorites() {
        return getReadableDatabase().rawQuery("SELECT * FROM learning WHERE is_favorite = 1 ORDER BY timestamp DESC", null);
    }
    public void updateFavorite(int id, int isFavorite) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("is_favorite", isFavorite);
        db.update("learning", cv, "id = ?", new String[]{String.valueOf(id)});
    }
    public void deleteLearning(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete("learning", "id = ?", new String[]{String.valueOf(id)});
    }


}
