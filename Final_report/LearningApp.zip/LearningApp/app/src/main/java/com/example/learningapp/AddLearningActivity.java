package com.example.learningapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddLearningActivity extends AppCompatActivity {
    EditText etTitle, etDesc;
    CheckBox cbFavorite;
    Button btnSave;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_learning);

        etTitle = findViewById(R.id.et_title);
        etDesc = findViewById(R.id.et_description);
        cbFavorite = findViewById(R.id.cb_favorite);
        btnSave = findViewById(R.id.btn_save);
        db = new DBHelper(this);

        btnSave.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String desc = etDesc.getText().toString().trim();
            int isFavorite = cbFavorite.isChecked() ? 1 : 0;

            if (title.isEmpty() || desc.isEmpty()) {
                Toast.makeText(this, "모든 항목을 입력해주세요.", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted = db.insertLearning(title, desc, isFavorite);
            if (inserted) {
                Toast.makeText(this, "학습 내용이 저장되었습니다.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "저장 실패", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
