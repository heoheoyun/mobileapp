package com.example.learningapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView tvGoal;
    Button btnAdd, btnList, btnQuiz, btnFavorite, btnStats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvGoal = findViewById(R.id.tv_today_goal);
        btnAdd = findViewById(R.id.btn_add_learning);
        btnList = findViewById(R.id.btn_learning_list);
        btnQuiz = findViewById(R.id.btn_quiz);
        btnFavorite = findViewById(R.id.btn_favorite);
        btnStats = findViewById(R.id.btn_stats);

        // 버튼 클릭 시 각 Activity로 이동
        btnAdd.setOnClickListener(v -> startActivity(new Intent(this, AddLearningActivity.class)));
        btnList.setOnClickListener(v -> startActivity(new Intent(this, LearningListActivity.class)));
        btnQuiz.setOnClickListener(v -> startActivity(new Intent(this, QuizActivity.class)));
        btnFavorite.setOnClickListener(v -> startActivity(new Intent(this, FavoriteActivity.class)));
        btnStats.setOnClickListener(v -> startActivity(new Intent(this, StatsActivity.class)));
    }
}
