package com.example.learningapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.learningapp.model.LearningItem;
import java.util.ArrayList;
import java.util.List;

public class FavoriteActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    DBHelper db;
    List<LearningItem> favoriteList;
    LearningAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        recyclerView = findViewById(R.id.recycler_favorite);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        db = new DBHelper(this);
        favoriteList = new ArrayList<>();

        loadFavorites();
    }

    private void loadFavorites() {
        Cursor cursor = db.getFavorites();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
            String desc = cursor.getString(cursor.getColumnIndexOrThrow("description"));
            int isFav = cursor.getInt(cursor.getColumnIndexOrThrow("is_favorite"));
            favoriteList.add(new LearningItem(id, title, desc, isFav == 1));
        }

        adapter = new LearningAdapter(this, favoriteList, new LearningAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(LearningItem item) {
                // Handle regular click (you can add functionality here if needed)
            }

            @Override
            public void onItemLongClick(LearningItem item) {
                // Handle long click - remove from favorites
                db.updateFavorite(item.getId(), 0);
                Toast.makeText(FavoriteActivity.this, "즐겨찾기 해제됨", Toast.LENGTH_SHORT).show();
                recreate();
            }
        });

        recyclerView.setAdapter(adapter);
    }
}